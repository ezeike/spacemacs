+++
archetype = "chapter"
title = "{{ replace .Name "-" " " | title }}"
weight = 1
+++

This is a new chapter.