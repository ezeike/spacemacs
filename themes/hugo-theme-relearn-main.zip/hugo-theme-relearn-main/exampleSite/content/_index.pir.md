+++
archetype = "home"
description = "A theme fer Cap'n Hugo designed fer documentat'n."
title = "Cap'n Hugo Relearrrn Theme"
+++
{{< piratify true >}}