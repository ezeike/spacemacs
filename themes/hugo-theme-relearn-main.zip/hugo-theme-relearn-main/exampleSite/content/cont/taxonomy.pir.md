+++
categories = ["taxonomy", "content"]
tags = "tutorrrial"
title = "Taxonomy"
weight = 8
+++
{{< piratify >}}