---
description: |
  This be a plain plank test, an' th' beginn'n o' a YAML multiline description…
tags:
  - "Children"
title: "plank X"
weight: 1
---
{{< piratify >}}