+++
alwaysopen = false
tags = ["children", "non-hidden"]
title = "plank 2"
weight = 20
+++
{{< piratify >}}