+++
description = "Synchr'nize select'n o' content 'n different tabbed views"
title = "Tabs"
+++
{{< piratify >}}