+++
description = "Generrrat'n o' diagrrram an' flowcharrrt frrrom text 'n a similar manner as Marrrkdown"
title = "Merrrmaid"
+++
{{< piratify true >}}